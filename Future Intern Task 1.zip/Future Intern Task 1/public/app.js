const productsEl = document.getElementById('products');
const cartIcon = document.getElementById('cart-icon');
const cartModal = document.getElementById('cart-modal');
const cartItemsEl = document.getElementById('cart-items');
const cartCountEl = document.getElementById('cart-count');
const cartTotalEl = document.getElementById('cart-total');
const closeCartBtn = document.getElementById('close-cart');

let products = [];
let cart = [];

function renderProducts() {
    productsEl.innerHTML = '';
    products.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <div class="price">$${product.price.toFixed(2)}</div>
            <button data-id="${product.id}">Add to Cart</button>
        `;
        card.querySelector('button').onclick = () => addToCart(product.id);
        productsEl.appendChild(card);
    });
}

function renderCart() {
    cartItemsEl.innerHTML = '';
    let total = 0;
    cart.forEach(item => {
        const product = products.find(p => p.id === item.id);
        total += product.price * item.qty;
        const li = document.createElement('li');
        li.innerHTML = `
            ${product.name} x${item.qty}
            <button data-id="${item.id}">Remove</button>
        `;
        li.querySelector('button').onclick = () => removeFromCart(item.id);
        cartItemsEl.appendChild(li);
    });
    cartTotalEl.textContent = `Total: $${total.toFixed(2)}`;
    cartCountEl.textContent = cart.reduce((sum, item) => sum + item.qty, 0);
}

function addToCart(id) {
    const idx = cart.findIndex(item => item.id === id);
    if (idx > -1) {
        cart[idx].qty += 1;
    } else {
        cart.push({ id, qty: 1 });
    }
    saveCart();
    renderCart();
}

function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    saveCart();
    renderCart();
}

function saveCart() {
    fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cart)
    });
}

cartIcon.onclick = () => {
    cartModal.classList.remove('hidden');
    renderCart();
};
closeCartBtn.onclick = () => cartModal.classList.add('hidden');

async function init() {
    products = await fetch('/api/products').then(res => res.json());
    cart = await fetch('/api/cart').then(res => res.json());
    renderProducts();
    renderCart();
}
init();
