<?php
	$db = mysqli_connect('localhost','root','12345','freshshop');
	session_start();
	function get_cart_view($item_id)
	{
		global $db;
		$user_id = $_SESSION['user_id'];
		$query = "SELECT time_added FROM cart where user_id='$user_id'AND item_id='$item_id'";
		$stmt = $db->prepare($query);
		$stmt->execute();
		$stmt->bind_result($time);
		$stmt->store_result();
		if($stmt->num_rows==0)
			return 0;
		return 1;
	}
	function get_name_by_item_id($item_id)
	{
		global $db;
		$result=mysqli_query($db,"SELECT * FROM normal_items where item_id=".$item_id);
		return mysqli_fetch_assoc($result)['name'];
	}
	//echo get_name_by_item_id(1);
	function get_link_by_item_id($item_id)
	{
		global $db;
		$result=mysqli_query($db,"SELECT * FROM normal_items where item_id=".$item_id);
		return mysqli_fetch_assoc($result)['img_link'];	
	}
	function get_price_by_item_id($item_id)
	{
		global $db;
		$result=mysqli_query($db,"SELECT * FROM normal_items where item_id=".$item_id);
		return mysqli_fetch_assoc($result)['price'];
	}
	function get_all_info_by_item_id($item_id)
	{
		global $db;
		$name = get_name_by_item_id($item_id);
		$price = get_price_by_item_id($item_id);
		$item_link = get_link_by_item_id($item_id);
		return $name.'%'.$price.'%'.$item_link;
	}
	//echo get_price_by_item_id(1);
	
	//echo get_link_by_item_id(1);
?>