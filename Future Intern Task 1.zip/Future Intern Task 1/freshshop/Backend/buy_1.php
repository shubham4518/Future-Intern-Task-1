<?php
/*
	@Author Dr.Tiny
	this is the server side script to get all the comments
*/

	require('functions.php');
//	session_start();
	$currenttime = time();
	$user_id=$_SESSION['user_id'];
	$location = $_POST['location'];
	$pin_code = $_POST['pin_code'];
	$mobile_number = $_POST['mobile_number'];
	$query="SELECT item_id from cart where user_id='$user_id'";
				$stmt=$db->prepare($query);
				$stmt->execute();
				$stmt->bind_result($item_id);
				$result=$stmt->get_result();
				$item = [];
				while($row = mysqli_fetch_array($result))
				{
				    $item[] = $row;
				}
				for($i = 0;$i<sizeof($item);$i++)
				{
					$item_id = $item[$i][0];
					$q = "INSERT INTO all_orders VALUES('0','$user_id','$item_id','$location','$pin_code','$mobile_number','$currenttime')";
					$s = $db->prepare($q);
					$s->execute();
				}
				
				$que = "DELETE FROM cart WHERE user_id='$user_id'";
				$stm = $db->prepare($que);
				$stm->execute();
				header("location: ../order_placed.php");


?>

