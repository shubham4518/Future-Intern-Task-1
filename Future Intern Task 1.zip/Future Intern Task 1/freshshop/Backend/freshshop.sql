-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2023 at 06:06 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `freshshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `description` text NOT NULL,
  `img_link` varchar(250) DEFAULT NULL,
  `likes` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `user_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `time_added` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`user_id`, `item_id`, `time_added`) VALUES
(2, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `normal_items`
--

CREATE TABLE `normal_items` (
  `item_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(250) NOT NULL,
  `price` varchar(5) NOT NULL,
  `quantity` varchar(10) NOT NULL,
  `img_link` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `normal_items`
--

INSERT INTO `normal_items` (`item_id`, `name`, `price`, `quantity`, `img_link`) VALUES
(1, 'Tomato', '67', '99', 'items/Tomato_1679300501.jpg'),
(2, 'Garlic', '67', '98', 'items/Garlic_1679300520.jpg'),
(3, 'Red', '67', '98', 'items/Red_1679300531.jpg'),
(4, 'Blue', '67', '98', 'items/Blue_1679300544.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `user_ID` int(10) UNSIGNED NOT NULL,
  `user_name` char(50) NOT NULL,
  `user_pass` char(255) NOT NULL,
  `email` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`user_ID`, `user_name`, `user_pass`, `email`) VALUES
(1, 'Vishwajeet Rauniyar', '$2y$10$KUtwyBPNU8cLyjq4zuGf8eXliFWnHoLzNPxuWsmU3L/VznjBsP6pK', 'drtiny2001@gmail.com'),
(2, 'tiny', '$2y$10$Q4ei/EDLuJgx.BxQcE4W6OVbz1Vqgycs/qXff0ZkTvOy4MFgEwEzm', 'vishwajitrauniyar123@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `normal_items`
--
ALTER TABLE `normal_items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`user_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `normal_items`
--
ALTER TABLE `normal_items`
  MODIFY `item_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `user_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
