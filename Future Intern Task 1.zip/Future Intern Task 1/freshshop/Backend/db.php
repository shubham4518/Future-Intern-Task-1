<?php
	$db = mysqli_connect('localhost','root','12345','freshshop');
?>