<?php
	session_start(); // Getting set cookies
	header("Content-type: application/json");
	
	$item_id = isset($_POST['item_id'])? $_POST['item_id'] : '';
	$user_id = $_SESSION['user_id'];

	
	//$pin_code = isset($_POST['pin_code'])? $_POST['pin_code'] : '';
	if($user_id=='' || $item_id=='')
	{
		$message="Empty Field";
		print json_encode(['success'=>false,'message'=>$message]);
		exit;
	}
//___________________________________________________________________________________________________________________
	ob_start();
	date_default_timezone_set('UTC');
	$currenttime=time();
	$current=1;
	$db=mysqli_connect('localhost','root','12345','freshshop');    //connecting to database
	$flag=0;
	$zero=NULL;
//___________________________________________________________________________________________________________________
	try
	{
			 $query="INSERT INTO cart VALUES
			          (?,?,?)";
			 $stmt=$db->prepare($query);
			 $stmt->bind_param('iii',$user_id,$item_id,$currenttime);
			 $stmt->execute();
//_____________________________________________________________________________________________________________________
		if($stmt->affected_rows>0)
		{
			$db->close();
			print json_encode(['success'=>true]);
		}
		else
		{
			print json_encode(['success'=>false]);
				exit;
		}
	}
//____________________________________________________________________________________________________________________

	catch(\Exception $e)

	{
		print json_encode(['success'=>false,'error'=>$e->getMessage()]);
	}
?>
