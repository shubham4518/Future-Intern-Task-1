<?php
/*
	@Author Dr.Tiny
	this is the server side script to get all the comments
*/

	require('functions.php');
//	session_start();
	$user_id=$_SESSION['user_id'];
	ob_start();
	header("Content-type: application/json");
	date_default_timezone_set('UTC');
	
	$db=mysqli_connect('localhost','root','12345','freshshop');
	try
	{
		
		$currenttime=time();
				$query="SELECT * from cart where user_id='$user_id'";
				$stmt=$db->prepare($query);
				$stmt->execute();
				$stmt->bind_result($user_id,$item_id,$time_added);
				$result=$stmt->get_result();
				$items=[]; 
				while($post = $result->fetch_assoc())
				{
						$name=get_name_by_item_id($post['item_id']);
						$item_link=get_link_by_item_id($post['item_id']);
						$price =  get_price_by_item_id($post['item_id']);
						$post['name'] = $name;
						$post['item_link'] = $item_link;
						$post['price'] = $price;
						$items[]=$post;  ////('->'')
					
					
				}
				print json_encode(['success'=>true,'items'=>$items]);
				exit;
		
	}
	catch(\Exception $e)

	{
		print json_encode(['success'=>false,'error'=>$e->getMessage()]);
	}


?>