<?php
/*
	@Author Dr.Tiny
	this is the server side script to get all the comments
*/

	require('functions.php');
//	session_start();
	$user_id=$_SESSION['user_id'];
	$item_id = $_POST['item_id'];
	ob_start();
	header("Content-type: application/json");
	date_default_timezone_set('UTC');
	
	$db=mysqli_connect('localhost','root','12345','freshshop');
	try
	{
		
				$query="DELETE FROM cart where user_id='$user_id' AND item_id='$item_id'";
				$stmt=$db->prepare($query);
				$stmt->execute();
				print json_encode(['success'=>true]);
				exit;
		
	}
	catch(\Exception $e)

	{
		print json_encode(['success'=>false,'error'=>$e->getMessage()]);
	}


?>