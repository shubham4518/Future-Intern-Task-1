<?php
	session_start(); // Getting set cookies
	$u_name=isset($_POST['name'])? $_POST['name'] : '';    //Verifying empty entries
	$u_name=strip_tags($u_name);

	$password=isset($_POST['password'])? $_POST['password'] : '';
	$pass=strip_tags($password);

	ob_start();
	header("Content-type: application/json");
	date_default_timezone_set('UTC');
	$current=1;
	$db=mysqli_connect('localhost','root','12345','freshshop');    //connecting to database
	$flag=0;

	try
	{	
				$query="SELECT user_ID,user_name,user_pass,email FROM user_details WHERE user_name = ?";   //Password authentication
   				$stmt=$db->prepare($query);
   				$stmt->bind_param('s',$u_name);
   				$stmt->execute();
   				$stmt->bind_result($ID,$name,$en_pass,$Email);
   				$stmt->store_result();
   				
   				if($stmt->num_rows==0)
  				 {
      				print json_encode(['success'=>false,'message'=>1]);
   				}
   				while ($stmt->fetch()) // In case of more than one user of given name 
   				{
      				if(($u_name==$name || $u_name==$Email) && (password_verify($pass, $en_pass)))//Encryted password verification
      				{
			         
			         	$_SESSION['user_name']=$name;  //Setting up cookies
			         	$_SESSION['user_pass']=$pass;
			         	$_SESSION['user_id']=$ID;
			         	$_SESSION['login']=true;
                        $flag=1;
			         	print json_encode(['success'=>true]);      //password verified message to fronte
			         	break;   

     			 }
     			 if($flag==0)
     			 {
     			 	print json_encode(['success'=>false,'message'=>0]);    //Wrong password message to frontend
     			 }
   }

		
	}
	catch(\Exception $e)

	{
		print json_encode(['success'=>false,'error'=>$e->getMessage()]);   //for debuggging
	}


?>