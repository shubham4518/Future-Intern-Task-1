<?php
/*
	@Author Dr.Tiny
	this is the server side script to get all the comments
*/

	require('functions.php');
//	session_start();
	$currenttime = time();
	$user_name=$_POST['name'];
	$email = $_POST['email'];
	$subject = $_POST['subject'];
	$text = $_POST['text'];
	$query="INSERT INTO feedback VALUES('0','$name','$email','$subject','$text')";
				$stmt=$db->prepare($query);
				$stmt->execute();
	print json_decode(["success"=>true]);
/*
CREATE TABLE feedback
(
	feedback_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	name VARCHAR(250) NOT NULL,
	email VARCHAR(50) NOT NULL,
	subject VARCHAR(100) NOT NULL,
	text text 
)

*/

?>

