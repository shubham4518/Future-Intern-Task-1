<?php
	session_start(); // Getting set cookies
	header("Content-type: application/json");
	$u_name = isset($_POST['name'])? $_POST['name'] : '';    //Verifying empty entries
	$u_name = strip_tags($u_name);
	$password = isset($_POST['password'])? $_POST['password'] : '';
	$email = isset($_POST['email'])? $_POST['email'] : '';

	
	//$pin_code = isset($_POST['pin_code'])? $_POST['pin_code'] : '';
	if($u_name=='' || $password=='' || $email=='')
	{
		$message="Empty Field";
		print json_encode(['success'=>false,'message'=>$message]);
		exit;
	}
	$pass=strip_tags($password);
	$pass = password_hash($pass, PASSWORD_DEFAULT);   //Encrypting password most powerful hashing in my knowledge

//___________________________________________________________________________________________________________________
	ob_start();
	
	date_default_timezone_set('UTC');
	$currenttime=time();
	$current=1;
	$db=mysqli_connect('localhost','root','12345','freshshop');    //connecting to database
	$flag=0;
	$zero=NULL;
//___________________________________________________________________________________________________________________
	try
	{
			 $query="INSERT INTO user_details VALUES
			          (?,?,?,?)";
			// $query_2="INSERT INTO user_useless VALUES
			 //			(?,?,?)";
			 //$query_3="INSERT INTO user_data VALUES
			 	//		(?,?,?)";                  //It is only for record when user has register to our website
			// $stmt_2=$db->prepare($query_2);
			 $stmt=$db->prepare($query);
			// $stmt_3=$db->prepare($query_3);
			 $stmt->bind_param('isss',$zero,$u_name,$pass,$email);
			// $stmt_2->bind_param('isi',$zero,$city_name,$currenttime);
			 //$stmt_3->bind_param('iis',$zero,$std,$school_name);
			 $stmt->execute();
			 //$stmt_2->execute();
			 //$stmt_3->execute();
//_____________________________________________________________________________________________________________________
		if($stmt->affected_rows>0)
		{
			$db->close();
			print json_encode(['success'=>true]);
		}
		else
		{
			print json_encode(['success'=>false]);
				exit;
		}
	}
//____________________________________________________________________________________________________________________

	catch(\Exception $e)

	{
		print json_encode(['success'=>false,'error'=>$e->getMessage()]);
	}


?>
