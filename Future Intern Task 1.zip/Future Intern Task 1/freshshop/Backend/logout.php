<?php
session_start();
session_destroy();
//header("location:../events");



?>
<script type="text/javascript">
	window.location.replace('../login.php');
</script>