<?php
	session_start(); // Getting set cookies
	$email =$_POST['email'];
	header("Content-type: application/json");
	
	$password  = isset($_POST['password'])? $_POST['password'] : '';
	

	
	//$pin_code = isset($_POST['pin_code'])? $_POST['pin_code'] : '';
	if($password=='' || $email=='')
	{
		$message="Empty Field";
		print json_encode(['success'=>false,'message'=>$message]);
		exit;
	}
	$pass=strip_tags($password);
	$pass = password_hash($pass, PASSWORD_DEFAULT);   //Encrypting password most powerful hashing in my knowledge

//___________________________________________________________________________________________________________________
	ob_start();
	
	date_default_timezone_set('UTC');
	$currenttime=time();
	$current=1;
	$db=mysqli_connect('localhost','root','12345','freshshop');    //connecting to database
	$flag=0;
	$zero=NULL;
//___________________________________________________________________________________________________________________
	try
	{
			 $query="UPDATE user_details 
			 		SET user_pass = '$pass'
			 		WHERE email = '$email'";
			 $stmt=$db->prepare($query);
			 $stmt->execute();
			 
//_____________________________________________________________________________________________________________________
		if($stmt->affected_rows>0)
		{
			$db->close();
			print json_encode(['success'=>true]);
		}
		else
		{
			print json_encode(['success'=>false]);
				exit;
		}
	}
//____________________________________________________________________________________________________________________

	catch(\Exception $e)

	{
		print json_encode(['success'=>false,'error'=>$e->getMessage()]);
	}


?>
