<?php
/*
	@Author Dr.Tiny
	this is the server side script to get all the comments
*/

	require('functions.php');
//	session_start();
	$user_id=$_SESSION['user_id'];
	$item_id = $_POST['item_id'];
	ob_start();
	header("Content-type: application/json");
	date_default_timezone_set('UTC');
	$info = get_all_info_by_item_id($item_id);
	$array = explode('%',$info);
	$item = [];
	$item['name'] = $array[0];
	$item['price'] = $array[1];
	$item['item_link'] = $array[2];
	print json_encode(['success'=>true,'info'=>$item]);
	exit;


?>