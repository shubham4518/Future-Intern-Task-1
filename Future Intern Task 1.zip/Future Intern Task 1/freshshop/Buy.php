<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Student</title>
  <link rel="stylesheet" type="text/css" href="index.css">
</head>
<body> 
  <!-- <nav>
      <div class="header">
  <a href="#default" class="logo">CompanyLogo</a>
  <div class="header-right">
    <a class="active" href="#home">Home</a>
    <a href="#contact">Contact</a>
    <a href="#about">About</a>
    <a href="Servies.php">Servies</a>
  </div>
</div>

  </nav> -->
   <div class="main">
    <div class="register">
      <h2> Fill Details Here</h2>
      <form method="post" action="Backend/buy_1.php">
        <center>
        <label>Name:</label><br>
        <input type="text" name="name"  id="name"placeholder="Name"><br><br>
        <label>Location:</label><br>
        <input type="text" name="location" placeholder="location"><br><br>
        <label>Moblie Number</label><br>
        <input type="text" name="moblie_number" id="mobile_number"placeholder="Moblie-Number"maxlength="10"><br><br>
        <label>Pin-Number</label><br>
        <input type="text" name="pin_code" id ="name"placeholder="pin-code" maxlength="6"><br><br>
      <!--   <label>Gender:</label><br>
        &nbsp;&nbsp;&nbsp;
        <input type="radio" name="Gender"value="male">
        &nbsp;
        <span>Male</span>
        &nbsp;&nbsp;&nbsp;
        <input type="radio" name="Gender"value="female">
        &nbsp;
        <span>Female</span><br><br>
        <label>Know Language</label><br>
        &nbsp;&nbsp;&nbsp;
        <input type="checkbox" name="lang"value="English">
        &nbsp;
        <span>English</span>
             &nbsp;&nbsp;&nbsp;
        <input type="checkbox" name="lang"value="Hindi">
        &nbsp;
        <span>Hindi</span>
             &nbsp;&nbsp;&nbsp;
        <input type="checkbox" name="lang"value="Urdu">
        &nbsp;
        <span>Urdu</span><br><br> -->
        <input type="submit" value="submit" name="submit" id="submit">
         </center>
      </form>
    </div>
   </div>
</body>
</html>

<?php
/*
 CREATE TABLE all_orders
 (
   order_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
   user_id INT NOT NULL,
   item_id INT NOT NULL,
   location VARCHAR(250) NOT NULL,
   pin_code VARCHAR(6) NOT NULL,
   mobile_num VARCHAR(13) NOT NULL,
   time date
 );

*/
?>