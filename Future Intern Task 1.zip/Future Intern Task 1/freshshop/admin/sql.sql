CREATE TABLE normal_items
(
	item_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	name VARCHAR(250) NOT NULL,
	price VARCHAR(5) NOT NULL,
	quantity VARCHAR(10) NOT NULL,
	img_link VARCHAR(250) NOT NULL 
)
CREATE TABLE blog
(
	description text NOT NULL,
	img_link VARCHAR(250),
	likes INT(11)
);

CREATE TABLE cart
(
	user_id INT(11),
	item_id INT(11),
	time_added date
);

ALTER TABLE normal_items 
ADD item_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY
FIRST name 