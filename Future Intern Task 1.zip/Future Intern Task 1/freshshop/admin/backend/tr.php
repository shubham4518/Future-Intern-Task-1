<?php
	$string = "hello.php";
	$name = explode('.', $string);
	echo $name[sizeof($name)-1];
	//$array[-1];
?>