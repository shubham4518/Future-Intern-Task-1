<?php

if (0 < $_FILES['file']['error']) {
    echo 'Error: ' . $_FILES['file']['error'] . '<br>';
} else {
      $name = $_POST['name'];
      $price = $_POST['price'];
      $quantity = $_POST['quantity'];
      $currenttime = time();
       $file_name = $_FILES['file']['name'];
       $array = explode('.',$file_name);
       $extension = $array[sizeof($array)-1];
       $dup_name = $name.'_'.$currenttime.'.'.$extension;
    move_uploaded_file($_FILES['file']['tmp_name'], '../../items/'.$dup_name);
    $link = 'items/'.$dup_name;
    $db = mysqli_connect('localhost','root','12345','freshshop');
    $query = "INSERT INTO normal_items VALUES('0','$name','$price','$quantity','$link')";
    $stmt = $db->prepare($query);
    $stmt->execute();

    echo "File uploaded successfully!!";
}

?>