/*
// Version 1.0
// iTech Empires - jQuery File Upload Script
*/
function uploadFile() {
    if ($("#file_to_upload").val() != "") {
        var file_data = $('#file_to_upload').prop('files')[0];
        var form_data = new FormData();
        var name = $('#name').val();
        var price = $('#price').val();
        var quantity = $('#quantity').val();

        form_data.append('file', file_data);
        form_data.append('name',name);
        form_data.append('price',price);
        form_data.append('quantity',quantity);

        $.ajax({
            url: 'backend/upload.php', // point to server-side PHP script
            dataType: 'text', // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type: 'post',
            success: function (data) {
                // get server responce here
                alert(data);
                // clear file field
                $("#file_to_upload").val("");
            }
        });
    }
    else {
        alert("Please select file!");
    }
}