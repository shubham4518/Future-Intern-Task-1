<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>iTech Empires Demo - PHP File upload using jQuery</title>

    <!-- Bootstrap CSS File -->
    <link
      rel="stylesheet"
      type="text/css"
      href="bootstrap-3.3.5-dist/css/bootstrap.css"
    />
  </head>
  <body>
    <!-- Content Section -->
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h2>PHP File Upload using jQuery</h2>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 col-md-offset-0">
          <div class="form-group">
            <form enctype="multipart/form-data">
              <label>Select File to Upload</label>
              <input id="file_to_upload" type="file" class="form-control" /><br>
              <input type="text" id="name" placeholder="name"><br>
              <input type="number" id="price" placeholder="price"><br>
              <input type="number" id="quantity" placeholder="quantity">


            </form>
          </div>
          <div class="form-group">
            <button onclick="uploadFile()" class="btn btn-primary">
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
    <!-- /Content Section -->

    <!-- Jquery JS file -->
    <script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap JS file -->
    <script
      type="text/javascript"
      src="bootstrap-3.3.5-dist/js/bootstrap.min.js"
    ></script>

    <!-- Custom JS file -->
    <script src="//code.jquery.com/jquery-2.2.3.min.js"></script>
    <script type="text/javascript" src="script.js"></script>
  </body>
</html>