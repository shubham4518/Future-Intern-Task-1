<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Order Placed</title>
</head>
<body>
	<h1>Your order is on the way</h1>
	<a href="index.php">Click here for home page</a>
</body>
</html>