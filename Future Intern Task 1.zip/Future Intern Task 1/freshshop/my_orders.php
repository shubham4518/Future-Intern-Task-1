<<!DOCTYPE html>
<html>
<head>
	<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Freshshop - Ecommerce Bootstrap 4 HTML Template</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
</head>
<body>
    <h1 align="center">All My Orders</h1>
	<?php
	require('Backend/functions.php');
	$user_id = $_SESSION['user_id'];
	$query = "SELECT * FROM all_orders WHERE user_id = '$user_id'";
	$stmt = $db->prepare($query);
	$stmt->execute();
	$stmt->bind_result($order_id,$user_id,$item_id,$location,$pin_code,$mobile_num,$time);
	$result=$stmt->get_result();
	echo ' <div class="row special-list" id="items">';
	while($post = $result->fetch_assoc())
	{
	//	$price = ;
		$name = get_name_by_item_id($post['item_id']);
		$item_link = get_link_by_item_id($post['item_id']);
	echo '<div class="col-lg-3 col-md-6 special-grid best-seller" id="">
                    <div class="products-single fix">
                        <div class="box-img-hover">
                            <div class="type-lb">
                                <p class="sale">Ordered</p>
                            </div>
                            <img src="'.$item_link.'" width = "300" height="300" alt="Image">
                            <div class="mask-icon">
                                <ul>
                                    <li><a href="#" data-toggle="tooltip" data-placement="right" title="View"><i class="fas fa-eye"></i></a></li>
                                    <li><a href="#" data-toggle="tooltip" data-placement="right" title="Compare"><i class="fas fa-sync-alt"></i></a></li>
                                    <li><a href="#" data-toggle="tooltip" data-placement="right" title="Add to Wishlist"><i class="far fa-heart"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="why-text">
                            <h4>Item Name: '.$name.'</h4>
                            <h4>Pin Code: '.$post['pin_code'].'</h4>
                            <h4>Location: '.$post['location'].'</h4>
                            <h5>Mobile Number: '.$post["mobile_num"].'</h5>
                        </div>
                    </div>
                </div>';
            }
           echo '</div>';

?>
</body>
</html>
