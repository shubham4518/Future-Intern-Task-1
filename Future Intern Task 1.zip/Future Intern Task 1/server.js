const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Load products from JSON
function getProducts() {
    return JSON.parse(fs.readFileSync('products.json', 'utf-8'));
}

// Products endpoint
app.get('/api/products', (req, res) => {
    res.json(getProducts());
});

// Cart endpoint (in-memory for demo)
let cart = [];

app.get('/api/cart', (req, res) => {
    res.json(cart);
});

app.post('/api/cart', (req, res) => {
    cart = req.body;
    res.json({ success: true });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
